# pyVisor

pyVisor is an package - webAplication to
view the content of an python object

## How to install 

use the script <code>python ./SCRIPT_installFromSource.py</code>

## How to use

python scpript:
<code>
from pyVisor import visor
v=visor(object,"NameObject")
v.run()
</code>


writed by:
[Edwin Saul ](http://edwinsaul.com)

