from setuptools import setup, find_packages

setup(
    name='pyVisor',         
    version='0.0.1', 
    description='package for simple exploring of python objects',
    author='Edwin Saul',
    author_email='edwinsaulpm@gmail.com',
    packages=find_packages(),  # Automatically discover and include all packages
    keywords='DEV debug flask',
    install_requires=[
    ],
)
